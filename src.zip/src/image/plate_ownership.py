"""Stateful image plate ownership using relative geometry and history.

This resolver consumes raw per-track plate candidates, resolves one frame at a
time, and updates bounded history only from trusted ownership decisions.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from math import isfinite
from typing import Iterable, Sequence

import numpy as np

from ..config import TemporalPlateOwnershipConfig
from .plate_types import ImagePlateCandidate
from ..core.plate_geometry import (
    intersection_area as _intersection_area,
    bbox_center,
    bbox_iou,
    intersection_over_plate_area,
    point_inside_bbox,
    valid_bbox as _valid_bbox,
)
from .matching import INF_COST, linear_assignment


BBox = tuple[int, int, int, int]


@dataclass(frozen=True, slots=True)
class RelativePlateGeometry:
    """Plate location and scale normalized by its parent vehicle bbox."""

    center_x: float
    center_y: float
    relative_width: float
    relative_height: float
    relative_area: float




@dataclass(frozen=True, slots=True)
class TemporalCandidateDiagnostic:
    vehicle_index: int
    plate_bbox: BBox
    vehicle_bbox: BBox
    relative_geometry: RelativePlateGeometry
    containment_score: float
    temporal_score: float
    tight_parent_score: float
    owner_score: float
    history_samples: int
    history_reliable: bool
    conflict_group: int | None
    selected: bool
    history_updated: bool
    rejected_by_history: bool


@dataclass(frozen=True, slots=True)
class TemporalPlateOwnershipStats:
    raw_candidates: int
    invalid_candidates: int
    conflict_groups: int
    definite_duplicate_groups: int
    ambiguous_conflict_groups: int
    removed_conflict_candidates: int
    final_results: int
    changed_owner_groups: int
    history_updates: int
    temporal_outliers_rejected: int
    elapsed_ms: float
    relative_geometry_ms: float
    history_scoring_ms: float


@dataclass(frozen=True, slots=True)
class TemporalPlateOwnershipResolution:
    candidates: tuple[ImagePlateCandidate, ...]
    stats: TemporalPlateOwnershipStats
    diagnostics: tuple[TemporalCandidateDiagnostic, ...] = ()


@dataclass(slots=True)
class _CandidateState:
    candidate: ImagePlateCandidate
    geometry: RelativePlateGeometry
    containment_score: float
    temporal_score: float
    tight_parent_score: float = 0.0
    owner_score: float = 0.0
    history_samples: int = 0
    history_reliable: bool = False
    conflict_group: int | None = None
    selected: bool = False
    history_updated: bool = False
    rejected_by_history: bool = False


def compute_relative_geometry(
    plate_bbox: BBox,
    vehicle_bbox: BBox,
) -> RelativePlateGeometry:
    """Return finite plate geometry normalized by a vehicle bbox."""

    if not _valid_bbox(vehicle_bbox):
        raise ValueError(f"vehicle_bbox must have positive finite area: {vehicle_bbox}")
    if not _valid_bbox(plate_bbox):
        raise ValueError(f"plate_bbox must have positive finite area: {plate_bbox}")

    vehicle_width = float(vehicle_bbox[2] - vehicle_bbox[0])
    vehicle_height = float(vehicle_bbox[3] - vehicle_bbox[1])
    plate_width = float(plate_bbox[2] - plate_bbox[0])
    plate_height = float(plate_bbox[3] - plate_bbox[1])
    plate_center_x = (plate_bbox[0] + plate_bbox[2]) / 2.0
    plate_center_y = (plate_bbox[1] + plate_bbox[3]) / 2.0
    vehicle_area = vehicle_width * vehicle_height
    values = (
        (plate_center_x - vehicle_bbox[0]) / vehicle_width,
        (plate_center_y - vehicle_bbox[1]) / vehicle_height,
        plate_width / vehicle_width,
        plate_height / vehicle_height,
        (plate_width * plate_height) / vehicle_area,
    )
    if not all(isfinite(value) for value in values):
        raise ValueError("relative plate geometry must be finite")
    return RelativePlateGeometry(*values)


def _clamp_score(value: float) -> float:
    return float(np.clip(value, 0.0, 1.0))


class TemporalPlateOwnershipResolver:
    """Resolve raw per-track candidates while learning bounded track history."""

    def __init__(self, config: TemporalPlateOwnershipConfig | None = None) -> None:
        self.config = config or TemporalPlateOwnershipConfig()
        self._history: dict[int, deque[RelativePlateGeometry]] = {}
        self.last_resolution: TemporalPlateOwnershipResolution | None = None
        self.total_elapsed_seconds = 0.0
        self.total_relative_geometry_seconds = 0.0
        self.total_history_scoring_seconds = 0.0
        self.total_history_updates = 0

    @property
    def history(self) -> dict[int, tuple[RelativePlateGeometry, ...]]:
        """Expose immutable snapshots for debug/tests."""

        return {vehicle_index: tuple(values) for vehicle_index, values in self._history.items()}

    def cleanup(self, active_vehicle_indices: Iterable[int]) -> None:
        """Drop histories for image vehicle indices no longer present."""

        active = {int(vehicle_index) for vehicle_index in active_vehicle_indices}
        for vehicle_index in tuple(self._history):
            if vehicle_index not in active:
                del self._history[vehicle_index]

    def resolve(
        self,
        frame_index: int,
        candidates: Sequence[ImagePlateCandidate],
    ) -> TemporalPlateOwnershipResolution:
        """Resolve one frame of raw candidates and safely update history."""

        started = time.perf_counter()
        if frame_index < 0:
            raise ValueError("frame_index must be non-negative")
        if any(candidate.frame_index != frame_index for candidate in candidates):
            raise ValueError("All plate ownership candidates must match frame_index")

        geometry_started = time.perf_counter()
        states: list[_CandidateState] = []
        invalid_count = 0
        for candidate in candidates:
            if not self._valid_candidate(candidate):
                invalid_count += 1
                continue
            geometry = compute_relative_geometry(
                candidate.plate_bbox, candidate.vehicle_bbox
            )
            states.append(
                _CandidateState(
                    candidate=candidate,
                    geometry=geometry,
                    containment_score=intersection_over_plate_area(
                        candidate.plate_bbox, candidate.vehicle_bbox
                    ),
                    temporal_score=0.0,
                )
            )
        geometry_elapsed = time.perf_counter() - geometry_started

        history_scoring_started = time.perf_counter()
        for state in states:
            (
                state.temporal_score,
                state.history_samples,
                state.history_reliable,
            ) = self._temporal_score(state.candidate.vehicle_index, state.geometry)
            if self._is_temporal_outlier(state):
                state.rejected_by_history = True
        history_scoring_elapsed = time.perf_counter() - history_scoring_started

        eligible_states = [state for state in states if not state.rejected_by_history]
        groups = self._conflict_groups(eligible_states)
        conflict_groups = 0
        definite_groups = 0
        ambiguous_groups = 0
        removed_candidates = 0
        changed_owner_groups = 0
        history_updates = 0
        temporal_outliers_rejected = sum(
            state.rejected_by_history for state in states
        )

        # First cluster observations of the same physical plate.  Selection is
        # then a one-to-one assignment between tracks and physical plates.  A
        # same-track edge must not join two physical groups: doing that makes
        # the transitive component swallow both nearby vehicles and retain
        # only one plate for the whole frame.
        group_by_state_id: dict[int, int] = {}
        for group_index, group in enumerate(groups):
            for state in group:
                state.conflict_group = group_index if len(group) > 1 else None
                group_by_state_id[id(state)] = group_index
            if len(group) == 1:
                state = group[0]
                state.tight_parent_score = 1.0
                state.owner_score = self._owner_score(state)
            else:
                conflict_groups += 1
                if self._group_is_definite_duplicate(group):
                    definite_groups += 1
                else:
                    ambiguous_groups += 1
                max_relative_area = max(
                    state.geometry.relative_area for state in group
                )
                for state in group:
                    state.tight_parent_score = _clamp_score(
                        state.geometry.relative_area / max_relative_area
                        if max_relative_area > 0.0
                        else 0.0
                    )
                    state.owner_score = self._owner_score(state)

        # Distinct physical groups offered to the same track are also a
        # selection conflict, even though they must stay separate for the
        # global one-to-one assignment above.
        groups_by_vehicle: dict[int, set[int]] = {}
        for state in eligible_states:
            groups_by_vehicle.setdefault(state.candidate.vehicle_index, set()).add(
                group_by_state_id[id(state)]
            )
        same_track_conflicts = sum(
            len(group_indexes) > 1
            for group_indexes in groups_by_vehicle.values()
        )
        conflict_groups += same_track_conflicts
        ambiguous_groups += same_track_conflicts

        selected_states = self._assign_tracks_to_plate_groups(groups)
        selected_ids = {id(state) for state in selected_states}
        removed_candidates = len(eligible_states) - len(selected_states)
        for state in selected_states:
            state.selected = True
            group_index = group_by_state_id[id(state)]
            group = groups[group_index]
            if (
                len(group) > 1
                and self._legacy_owner(group) != state.candidate.vehicle_index
            ):
                changed_owner_groups += 1

            competitors = [
                other
                for other in eligible_states
                if id(other) not in selected_ids
                and (
                    other.candidate.vehicle_index == state.candidate.vehicle_index
                    or group_by_state_id[id(other)] == group_index
                )
            ]
            margin = (
                state.owner_score
                - max(other.owner_score for other in competitors)
                if competitors
                else float("inf")
            )
            if margin >= self.config.min_history_update_margin:
                self._update_history(state)
                state.history_updated = True
                history_updates += 1

        selected = [state.candidate for state in selected_states]

        selected.sort(key=lambda candidate: candidate.vehicle_index)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        self.total_elapsed_seconds += elapsed_ms / 1000.0
        self.total_relative_geometry_seconds += geometry_elapsed
        self.total_history_scoring_seconds += history_scoring_elapsed
        self.total_history_updates += history_updates

        resolution = TemporalPlateOwnershipResolution(
            candidates=tuple(selected),
            stats=TemporalPlateOwnershipStats(
                raw_candidates=len(candidates),
                invalid_candidates=invalid_count,
                conflict_groups=conflict_groups,
                definite_duplicate_groups=definite_groups,
                ambiguous_conflict_groups=ambiguous_groups,
                removed_conflict_candidates=removed_candidates,
                final_results=len(selected),
                changed_owner_groups=changed_owner_groups,
                history_updates=history_updates,
                temporal_outliers_rejected=temporal_outliers_rejected,
                elapsed_ms=elapsed_ms,
                relative_geometry_ms=geometry_elapsed * 1000.0,
                history_scoring_ms=history_scoring_elapsed * 1000.0,
            ),
            diagnostics=tuple(self._diagnostic(state) for state in states),
        )
        self.last_resolution = resolution
        return resolution

    def _valid_candidate(self, candidate: ImagePlateCandidate) -> bool:
        return (
            _valid_bbox(candidate.plate_bbox)
            and _valid_bbox(candidate.vehicle_bbox)
            and point_inside_bbox(
                bbox_center(candidate.plate_bbox),
                candidate.vehicle_bbox,
            )
        )

    def _history_for(self, vehicle_index: int) -> deque[RelativePlateGeometry]:
        return self._history.setdefault(
            vehicle_index, deque(maxlen=self.config.history_size)
        )

    def _temporal_score(
        self, vehicle_index: int, geometry: RelativePlateGeometry
    ) -> tuple[float, int, bool]:
        history = self._history.get(vehicle_index)
        samples = len(history) if history is not None else 0
        if samples < self.config.min_history_samples:
            return self.config.cold_start_temporal_score, samples, False

        values = np.asarray(
            [
                (
                    item.center_x,
                    item.center_y,
                    item.relative_width,
                    item.relative_height,
                )
                for item in history
            ],
            dtype=np.float64,
        )
        current = np.asarray(
            [
                geometry.center_x,
                geometry.center_y,
                geometry.relative_width,
                geometry.relative_height,
            ],
            dtype=np.float64,
        )
        median = np.median(values, axis=0)
        mad = np.median(np.abs(values - median), axis=0)
        robust_scale = 1.4826 * mad
        configured_tolerance = np.asarray(
            [
                self.config.center_x_tolerance,
                self.config.center_y_tolerance,
                self.config.relative_width_tolerance,
                self.config.relative_height_tolerance,
            ],
            dtype=np.float64,
        )
        minimum_scale = np.asarray(
            [
                self.config.minimum_center_scale,
                self.config.minimum_center_scale,
                self.config.minimum_relative_size_scale,
                self.config.minimum_relative_size_scale,
            ],
            dtype=np.float64,
        )
        scale = np.maximum(robust_scale, minimum_scale)
        scale = np.maximum(scale, configured_tolerance)
        deviation = float(np.mean(np.abs(current - median) / scale))
        return float(np.exp(-deviation)), samples, True

    def _is_temporal_outlier(self, state: _CandidateState) -> bool:
        """Reject a mature track candidate that jumps away from plate history."""

        if not state.history_reliable:
            return False
        history = self._history.get(state.candidate.vehicle_index)
        if not history:
            return False
        previous = history[-1]
        center_jump = float(np.hypot(
            state.geometry.center_x - previous.center_x,
            state.geometry.center_y - previous.center_y,
        ))

        def size_ratio(current: float, prior: float) -> float:
            smaller = min(current, prior)
            if smaller <= 0.0:
                return float("inf")
            return max(current, prior) / smaller

        width_ratio = size_ratio(
            state.geometry.relative_width, previous.relative_width,
        )
        height_ratio = size_ratio(
            state.geometry.relative_height, previous.relative_height,
        )
        return (
            state.temporal_score < self.config.min_temporal_accept_score
            or center_jump > self.config.max_center_jump
            or width_ratio > self.config.max_relative_size_ratio
            or height_ratio > self.config.max_relative_size_ratio
        )

    def _conflict_groups(
        self, states: Sequence[_CandidateState]
    ) -> list[list[_CandidateState]]:
        """Cluster observations that refer to the same physical plate."""

        parents = list(range(len(states)))

        def find(index: int) -> int:
            while parents[index] != index:
                parents[index] = parents[parents[index]]
                index = parents[index]
            return index

        def union(first: int, second: int) -> None:
            first_root = find(first)
            second_root = find(second)
            if first_root != second_root:
                parents[second_root] = first_root

        for first in range(len(states)):
            for second in range(first + 1, len(states)):
                first_candidate = states[first].candidate
                second_candidate = states[second].candidate
                if bbox_iou(
                    first_candidate.plate_bbox, second_candidate.plate_bbox
                ) >= self.config.ownership_conflict_iou_threshold:
                    union(first, second)
                    continue
                overlap = _intersection_area(
                    first_candidate.plate_bbox, second_candidate.plate_bbox
                )
                first_area = (
                    first_candidate.plate_bbox[2] - first_candidate.plate_bbox[0]
                ) * (
                    first_candidate.plate_bbox[3] - first_candidate.plate_bbox[1]
                )
                second_area = (
                    second_candidate.plate_bbox[2] - second_candidate.plate_bbox[0]
                ) * (
                    second_candidate.plate_bbox[3] - second_candidate.plate_bbox[1]
                )
                smaller_area = min(first_area, second_area)
                if (
                    smaller_area > 0.0
                    and overlap / smaller_area
                    >= self.config.overlap_over_smaller_threshold
                ):
                    union(first, second)

        groups: dict[int, list[_CandidateState]] = {}
        for index, state in enumerate(states):
            groups.setdefault(find(index), []).append(state)
        return [groups[root] for root in sorted(groups)]

    def _assign_tracks_to_plate_groups(
        self, groups: Sequence[Sequence[_CandidateState]]
    ) -> list[_CandidateState]:
        """Return the best one-to-one track/physical-plate assignment."""

        vehicle_indices = sorted(
            {state.candidate.vehicle_index for group in groups for state in group}
        )
        if not vehicle_indices or not groups:
            return []

        vehicle_index_lookup = {
            vehicle_index: index for index, vehicle_index in enumerate(vehicle_indices)
        }
        best_edges: dict[tuple[int, int], _CandidateState] = {}
        for group_index, group in enumerate(groups):
            for state in group:
                edge = (vehicle_index_lookup[state.candidate.vehicle_index], group_index)
                previous = best_edges.get(edge)
                if previous is None or self._owner_key(state) > self._owner_key(
                    previous
                ):
                    best_edges[edge] = state

        costs = np.full(
            (len(vehicle_indices), len(groups)), INF_COST, dtype=np.float64
        )
        for edge, state in best_edges.items():
            costs[edge] = 1.0 - state.owner_score
        matches, _, _ = linear_assignment(costs, cost_limit=1.0)
        return [best_edges[(row, column)] for row, column in matches]

    def _group_is_definite_duplicate(self, group: Sequence[_CandidateState]) -> bool:
        for first in range(len(group)):
            for second in range(first + 1, len(group)):
                if (
                    bbox_iou(
                        group[first].candidate.plate_bbox,
                        group[second].candidate.plate_bbox,
                    )
                    >= self.config.definite_duplicate_iou_threshold
                ):
                    return True
        return False

    def _owner_score(self, state: _CandidateState) -> float:
        config = self.config
        return (
            config.temporal_weight * state.temporal_score
            + config.tight_parent_weight * state.tight_parent_score
            + config.containment_weight * state.containment_score
            + config.plate_conf_weight * _clamp_score(
                state.candidate.plate_confidence
            )
            + config.vehicle_conf_weight * _clamp_score(
                state.candidate.vehicle_confidence
            )
        )

    @staticmethod
    def _owner_key(state: _CandidateState) -> tuple[float, float, float, float, float, int]:
        return (
            state.owner_score,
            state.temporal_score,
            state.tight_parent_score,
            state.candidate.plate_confidence,
            state.candidate.vehicle_confidence,
            -state.candidate.vehicle_index,
        )

    @staticmethod
    def _legacy_owner(group: Sequence[_CandidateState]) -> int:
        return max(
            group,
            key=lambda state: (
                state.containment_score,
                state.candidate.plate_confidence,
                state.candidate.vehicle_confidence,
                -state.candidate.vehicle_index,
            ),
        ).candidate.vehicle_index

    def _update_history(self, state: _CandidateState) -> None:
        self._history_for(state.candidate.vehicle_index).append(state.geometry)

    def _diagnostic(self, state: _CandidateState) -> TemporalCandidateDiagnostic:
        return TemporalCandidateDiagnostic(
            vehicle_index=state.candidate.vehicle_index,
            plate_bbox=state.candidate.plate_bbox,
            vehicle_bbox=state.candidate.vehicle_bbox,
            relative_geometry=state.geometry,
            containment_score=state.containment_score,
            temporal_score=state.temporal_score,
            tight_parent_score=state.tight_parent_score,
            owner_score=state.owner_score,
            history_samples=state.history_samples,
            history_reliable=state.history_reliable,
            conflict_group=state.conflict_group,
            selected=state.selected,
            history_updated=state.history_updated,
            rejected_by_history=state.rejected_by_history,
        )
