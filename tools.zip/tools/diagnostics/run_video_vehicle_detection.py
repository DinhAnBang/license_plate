"""Run only Module 2: YOLO26 vehicle detection on a video."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.paths import application_directory
from src.video.vehicle_stage import run_video_vehicle_detection
from src.video.vehicle_validation import VehicleValidationConfig


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--model",
        type=Path,
        default=application_directory() / "models" / "vehicle" / "yolo26n.onnx",
    )
    parser.add_argument(
        "--confidence",
        type=float,
        default=0.10,
        help="minimum confidence sent to YOLO before validation",
    )
    parser.add_argument("--min-confidence", type=float, default=0.50)
    parser.add_argument("--min-width", type=int, default=8)
    parser.add_argument("--min-height", type=int, default=8)
    parser.add_argument(
        "--show-rejected",
        action="store_true",
        help="also draw rejected raw boxes in red",
    )
    parser.add_argument("--iou", type=float, default=0.45)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cpu")
    args = parser.parse_args()

    result = run_video_vehicle_detection(
        args.input,
        args.output_dir,
        model_path=args.model,
        confidence=args.confidence,
        iou=args.iou,
        device=args.device,
        validation_config=VehicleValidationConfig(
            min_confidence=args.min_confidence,
            min_width_pixels=args.min_width,
            min_height_pixels=args.min_height,
        ),
        show_rejected=args.show_rejected,
    )
    print(f"Frames: {result['summary']['frames_read']}")
    print(f"Raw vehicle boxes: {result['summary']['raw_vehicle_detections']}")
    print(f"Accepted vehicle boxes: {result['summary']['accepted_vehicle_detections']}")
    print(f"Rejected vehicle boxes: {result['summary']['rejected_vehicle_detections']}")
    print(f"JSON: {result['output_path']}")
    if "annotated_path" in result:
        print(f"Annotated: {result['annotated_path']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
